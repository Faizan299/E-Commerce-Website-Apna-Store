<?php
$SETTINGS["mysql_user"]='user';
$SETTINGS["mysql_pass"]='apnastore';
$SETTINGS["hostname"]='localhost';
$SETTINGS["mysql_database"]='apnastore';
$SETTINGS["USERS"] = 'php_users_login'; // this is the default table name that we used

/* Connect to MySQL */
$mysqli = new mysqli($SETTINGS["localhost"], $SETTINGS["root"], $SETTINGS[""],$SETTINGS["apnastore"]);
/* check connection */
if (mysqli_connect_error()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>