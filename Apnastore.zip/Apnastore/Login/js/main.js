var jQuery_1_8_2 = $.noConflict();
(function ($, undefined) {
	$(function () {
		var form = $('#login-form');
			
		if (form.length > 0) {
			form.validate({
			});
		}
		
	});
})(jQuery_1_8_2);
